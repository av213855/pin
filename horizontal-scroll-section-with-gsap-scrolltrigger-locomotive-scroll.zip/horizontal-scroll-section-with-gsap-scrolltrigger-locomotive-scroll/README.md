# Horizontal scroll section with GSAP ScrollTrigger & Locomotive Scroll

A Pen created on CodePen.io. Original URL: [https://codepen.io/AV213855/pen/XWPdyQx](https://codepen.io/AV213855/pen/XWPdyQx).

